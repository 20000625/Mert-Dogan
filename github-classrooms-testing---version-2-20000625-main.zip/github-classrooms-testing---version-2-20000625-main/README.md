# se1-week2-exercise

This week's exercise is just another test to see if the Moodle plugin for Github classrooms is working yet.

If you can see this (your) repo from the link in Moodle:

1. Clone the repo to your local machine
2. Edit it in any way you like
3. Commit your local change with a comment
4. Push your local changes back to your cloud repo.

Use the online documentation in Github to help you do this.git status

